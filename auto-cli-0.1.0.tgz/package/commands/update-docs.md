---
description: 更新项目文档
---

# 更新文档

从唯一数据源同步文档：

1. 读取 package.json 的 scripts 部分
   - 生成脚本参考表
   - 包含注释中的描述

2. 读取 .env.example
   - 提取所有环境变量
   - 记录用途和格式

3. 生成 docs/CONTRIB.md，包含：
   - 开发工作流程
   - 可用脚本
   - 环境设置
   - 测试流程

4. 生成 docs/RUNBOOK.md，包含：
   - 部署流程
   - 监控和告警
   - 常见问题及修复方法
   - 回滚流程

5. 识别过时文档：
   - 查找超过 90 天未修改的文档
   - 列出供人工审查

6. 显示差异摘要

唯一数据源：package.json 和 .env.example
